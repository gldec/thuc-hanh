class CongNhan {
    constructor(stt, hoTen, ngaySinh, diaChi, luong, chucVu) {
        this.stt = stt;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
        this.luong = luong;
        this.chucVu = chucVu;
    }
}

let danhSach = [
    new CongNhan(1, "Nguyen Van An", "01/01/2000", "Ha Noi", 10000000, "Cong nhan"),
    new CongNhan(2, "Tran Van Binh", "02/02/1999", "Hai Phong", 12000000, "To truong"),
    new CongNhan(3, "Le Thi Hoa", "03/03/2001", "Nam Dinh", 11000000, "Cong nhan"),
    new CongNhan(4, "Pham Van Cuong", "04/04/1998", "Ha Noi", 13000000, "Quan ly")
];

for (let i = 0; i < danhSach.length; i++) {
    console.log(
        danhSach[i].stt + " | " +
        danhSach[i].hoTen + " | " +
        danhSach[i].ngaySinh + " | " +
        danhSach[i].diaChi + " | " +
        danhSach[i].luong + " | " +
        danhSach[i].chucVu
    );
}