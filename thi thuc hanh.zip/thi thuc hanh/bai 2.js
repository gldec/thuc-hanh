function isSoHoanHao(n) {
    let sum =0;
    for(let i =1; i<n; i++){
        if(n %i == 0){
            sum += i;
        }
    }
    if( sum == n){
        return true;
    }
    return false;
}


let n = Number(prompt("Nhập giá trị của số cần kiểm tra"));
console.log(isSoHoanHao(n));