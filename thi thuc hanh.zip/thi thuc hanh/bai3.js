function check(input) {
    if (input.substring(2, 3) != "/") {
        return false;
    }
    let thang = Number(input.substring(0, 2));
    let nam = Number(input.substring(3, 7));

    if (thang < 1 || thang > 12) {
        return false;
    }
    if (nam < 1) {
        return false;
    }
    return true;
}
let input = prompt("Nhập tháng/năm (MM/yyyy):");


    if (!check(input)) {
        console.log("Tháng hoặc năm không hợp lệ");
    } 
    else {
        let thang = Number(input.substring(0, 2));
        let nam = Number(input.substring(3, 7));
        let soNgay;
        if (thang == 2) {
            if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0)) {
                soNgay = 29;
            }
            else {
                soNgay = 28;
            }
        } 
        else if (thang == 4 || thang == 6 || thang == 9 || thang == 11) {
            soNgay = 30;
        } 
        else {
            soNgay = 31;
        }

        console.log("Tháng " + thang + " có " + soNgay + " ngày");
    }