let n = Number(prompt("Nhập số phần tử:"));

let a = [];
let sum = 0;
let count = 0;

for (let i = 0; i < n; i++) {
    a[i] = Number(prompt("Nhập a[" + i + "]:"));

    if (a[i] % 3 === 0) {
        sum += a[i];
        count++;
    }
}

if (count > 0) {
    let average = sum / count;
    console.log("Trung bình cộng =", average);
} else {
    console.log("Không có số nào chia hết cho 3");
}